from fuzzywuzzy import process   # importing process in fuzzywuzzy module

# This function for finding closest match
def find_closest_matches_in_sublists(query, list_of_lists, limit=5):
    all_matches = []
    for choices in list_of_lists:
        matches = process.extract(query, choices, limit=limit)
        all_matches.append(matches)
    return all_matches

# This function for finding best match
def find_best_match_in_sublists(query, list_of_lists):
    best_matches = []
    for choices in list_of_lists:
        best_match = process.extractOne(query, choices)
        best_matches.append(best_match)
    return best_matches

# Taking Query and choice input from the user
def get_user_input():
    query = input("Enter the query string: ")

    num_sublists = int(input("Enter the number of sublists: "))
    list_of_lists = []
    for i in range(num_sublists):
        num_choices = int(input(f"Enter the number of choices for sublist {i+1}: "))
        choices = []
        for j in range(num_choices):
            choice = input(f"Enter choice {j+1} for sublist {i+1}: ")
            choices.append(choice)
        list_of_lists.append(choices)
    
    return query, list_of_lists

if __name__ == "__main__":
    query, list_of_lists = get_user_input()  # Calling the get_user_input function

    # Gives a list of matches ordered by score for each sublist
    matches = find_closest_matches_in_sublists(query, list_of_lists)
    for i, match_list in enumerate(matches):
        print(f"Matches for sublist {i+1}: {match_list}")

    # Gives the best match from each sublist
    best_matches = find_best_match_in_sublists(query, list_of_lists)
    for i, best_match in enumerate(best_matches):
        print(f"Best match for sublist {i+1}: {best_match}")
